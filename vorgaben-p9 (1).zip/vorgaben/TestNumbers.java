public class TestNumbers {

    /* Aufgabenteil (a) */
    public static void print(Number[] numbers){
 
    }
    
    /* Aufgabenteil (b) */ 
    public static void sort(Number[] numbers){
 
    }

 
    public static void main(String[] args) {
        int k = 10;
        Number[] brueche = new Number[k];
        
        /* Aufgabenteil (d) */
 
        print(brueche);
        sort(brueche);
        print(brueche);
    }
}
