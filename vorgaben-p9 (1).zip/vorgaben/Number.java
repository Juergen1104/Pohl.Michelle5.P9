public interface Number {
    public double toDouble();
    public boolean equals(Number n2);
    public int compareTo(Number n2);

}
