public class Bruch {
    private int zaehler, nenner;

    public Bruch(int z, int n){
        this.zaehler = z;
        this.nenner = n;
    }

    public String toString(){
        return "(" +  this.zaehler + "/" + this.nenner + ")";
    }

    /* Aufgabenteil (c) */

}
